# Generative Adversarial Network (GAN)

Exploring the GAN achitecture on non-image data

## Prerequisites

- Python 3.10+
- PyTorch
- Pandas
- Numpy

### Datasets

---

## Usage

--- 