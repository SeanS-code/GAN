from model import gan_model

def main():
    gan_model()

if __name__ == "__main__":
    main()